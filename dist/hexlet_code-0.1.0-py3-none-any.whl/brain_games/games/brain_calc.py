#!/usr/bin/env python3
from brain_games.logic_for_brain_calc import game_calc


def main():
    print('Welcome to the Brain Games!')
    game_calc()


if __name__ == '__main__':
    main()
