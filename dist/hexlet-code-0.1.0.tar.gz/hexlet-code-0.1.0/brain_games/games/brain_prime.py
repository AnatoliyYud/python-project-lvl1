#!/usr/bin/env python3
from brain_games.logic_for_brain_prime import game_prime


def main():
    print('Welcome to the Brain Games!')
    game_prime()


if __name__ == '__main__':
    main()
