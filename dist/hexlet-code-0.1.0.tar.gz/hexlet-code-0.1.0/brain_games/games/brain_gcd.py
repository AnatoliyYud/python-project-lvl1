#!/usr/bin/env python3
from brain_games.logic_for_brain_gcd import game_gcd


def main():
    print('Welcome to the Brain Games!')
    game_gcd()


if __name__ == '__main__':
    main()
