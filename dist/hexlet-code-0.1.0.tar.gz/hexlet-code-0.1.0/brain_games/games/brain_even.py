#!/usr/bin/env python3
from brain_games.logic import game_even


def main():
    print('Welcome to the Brain Games!')
    game_even()


if __name__ == '__main__':
    main()
