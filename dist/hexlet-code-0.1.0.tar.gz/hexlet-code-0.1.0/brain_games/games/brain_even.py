#!/usr/bin/env python3
from brain_games.logic_for_brain_even import game_even


def main():
    print('Welcome to the Brain Games!')
    game_even()


if __name__ == '__main__':
    main()
